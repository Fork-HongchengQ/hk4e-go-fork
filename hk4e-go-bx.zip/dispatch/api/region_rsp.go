package api

type QueryCurRegionRspJson struct {
	Content string `json:"content"`
	Sign    string `json:"sign"`
}
