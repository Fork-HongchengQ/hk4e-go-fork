package constant

const (
	WEAPON_AWAKEN_MAX_REFINEMENT = 5 // 武器最大精炼等级
	WEAPON_AWAKEN_MIN_EQUIPLEVEL = 3 // 武器精炼最小星级
)
