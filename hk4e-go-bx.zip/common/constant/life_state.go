package constant

const (
	LIFE_STATE_NONE   = 0
	LIFE_STATE_ALIVE  = 1
	LIFE_STATE_DEAD   = 2
	LIFE_STATE_REVIVE = 3
)
