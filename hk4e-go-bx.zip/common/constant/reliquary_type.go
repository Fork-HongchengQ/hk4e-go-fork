package constant

const (
	RELIQUARY_TYPE_NONE    = 0
	RELIQUARY_TYPE_FLOWER  = 1 // 生之花
	RELIQUARY_TYPE_FEATHER = 2 // 死之羽
	RELIQUARY_TYPE_SAND    = 3 // 时之沙
	RELIQUARY_TYPE_CUP     = 4 // 空之杯
	RELIQUARY_TYPE_CROWN   = 5 // 理之冠
)
